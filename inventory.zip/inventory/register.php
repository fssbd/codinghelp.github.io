<!DOCTYPE html>
<html>
    <head>
        <title> Registration Form</title>
        <link rel="stylesheet" href="css/registrtn.css" type="text/css">
    </head>
    <body>
        <div class="Simple-Form">
            <form id="registration" method="post" action="process_registration.php">
                <input type="text" name="fname" id="button" placeholder="Enter Your First Name"><br><br>
                <input type="text" name="lname" id="button" placeholder="Enter Your Last Name"><br><br>
                <input type="email" name="email" id="button" placeholder="Enter Your Email Id"><br><br>
                <input type="pass" name="pass" id="button" placeholder="Enter Your PassWord"><br><br>
                <select id="ph"><option>+88</option><option>+91</option><option>+92</option><option>+93</option><option>+94</option></select>
                 <input type="number" name="num" placeholder="Enter Your Mobile Number" id="phone"><br><br>
                <input type="radio" name="gender" id="rd">&nbsp;&nbsp;&nbsp;&nbsp;<span id="but">Male</span>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="gender" id="rd">&nbsp;&nbsp;&nbsp;&nbsp;<span id="but">Female</span><br><br>
                <input type="submit" value="register" id="butt">
            </form>
        </div>
        
    </body>
</html>