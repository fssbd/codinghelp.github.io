<html>
<link href='css/navstyle.css' rel='stylesheet'>
<body>
    ...Inventory Management...
    
</body>
	<ul>
		<div class="header_right">
			<div class="login_register_btn">
			<a href="login.php">Login/</a>
			<a href="register.php">Register</a>
			</div>
		</div>
	</ul>
</html>
